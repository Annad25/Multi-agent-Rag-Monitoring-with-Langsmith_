import os

from langchain_community.utilities import OpenWeatherMapAPIWrapper

os.environ["OPENWEATHERMAP_API_KEY"] = "09347ca8ae2eded2a646dd59404693f1"

weather = OpenWeatherMapAPIWrapper()
