import streamlit as st
from backend import graph

import torch
# Option 1: Set to an empty list
torch.classes.__path__ = []
# Option 2: Set to a specific path (less common but can be useful in some setups)
# torch.classes.__path__ = [os.path.join(torch.__path__[0], torch.classes.__file__)]
# Initialize session state for chat history
if "messages" not in st.session_state:
    st.session_state["messages"] = [{"role": "system", "content": "You are a helpful assistant."}]

st.title("AI Engineer-  Assignment")

state = {"messages": [],
    "intent": "",
    "city":"",
    "next": ""}
# Display chat history
for message in st.session_state["messages"]:
    if message["role"] == "user":
        st.chat_message("user").markdown(message["content"])
    else:
        st.chat_message("assistant").markdown(message["content"])

# Accept user input
if prompt := st.chat_input("Type your message here..."):
    # Add user message to chat history
    st.session_state["messages"].append({"role": "user", "content": prompt})
    st.chat_message("user").markdown(prompt)

    # Generate response from OpenAI
    with st.chat_message("assistant"):
        state["messages"].extend(st.session_state["messages"])
        response = graph.invoke(state
        )
        print(response)
        reply = response['messages'][-1]
        st.markdown(reply)
        # Add assistant response to chat history
        st.session_state["messages"].append({"role": "assistant", "content": reply})