#from langchain.llms import Ollama
from langchain.prompts import PromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import PromptTemplate
import os
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage
from qdrant_client import QdrantClient
from qdrant_client.http.models import PointStruct, VectorParams
from qdrant_client.http.models import Distance, VectorParams
from langchain_qdrant import QdrantVectorStore

from qdrant_client import QdrantClient
from qdrant_client.http.models import PointStruct, VectorParams
from qdrant_client.http.models import Distance, VectorParams

from langchain_huggingface.embeddings import HuggingFaceEmbeddings

llm = ChatOpenAI(
    model="mistralai/mistral-small-3.2-24b-instruct:free",
    temperature=0.0,
    max_retries=2,
    openai_api_key="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",
    openai_api_base="https://openrouter.ai/api/v1",
)
embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")



prompt_template = PromptTemplate(
    input_variables=["query", "context"],
    template="Based on the following context, answer the question: {query}\n\nContext: {context}"
)
client = QdrantClient(path = "store")

vector_store = QdrantVectorStore(
    client=client,
    collection_name="pdfs",
    embedding=embeddings,

)
chain = (
    {"context": vector_store.as_retriever(), "query": RunnablePassthrough()}
    | prompt_template
    | llm
    | StrOutputParser()
)


