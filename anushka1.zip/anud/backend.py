from typing import Annotated
from typing_extensions import TypedDict
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from backend_func_weather import weather
from backend_func_rag import chain
from backend_route import classifier

from typing import Annotated, List
from langchain_core.messages import BaseMessage
from langsmith import traceable

import dotenv
dotenv.load_dotenv()

class State(TypedDict):
    messages: Annotated[List[BaseMessage], "Conversation messages"]
    intent: Annotated[str, "Detected user intent"]
    city: Annotated[str, "Detected city for weather"]
    next: Annotated[str, "Next action"]


@traceable
def generate_rag_answer(state: State):
    print(state)
    answer = chain.invoke(state["messages"][-1]['content'])
    return {"messages": [answer]}


@traceable
def get_weather_details(state: State):
    print(state)

    weather_info = weather.run(state["city"])
    info = f"Weather in {state['city']}:\n{weather_info}"
    return {"messages": [info]}



# Define routing function
@traceable
def get_user_intent(state: State) -> str:
    result = classifier.invoke({"question": state["messages"][-1]})
    city = result.get("city")  # optionally attach city to input
    intent = result.get("destination", "default")
    return {"intent": intent, "city": city}


def route_by_intent(state: State) -> str:
    """Route to different nodes based on detected intent."""
    intent = state["intent"].lower()
    
    if "question" in intent:
        return "rag"
    elif "weather" in intent:
        return "weather"
    else:
        return "rag"



# Create the graph
workflow = StateGraph(State)

# Add nodes
workflow.add_node("detect_intent", get_user_intent)
workflow.add_node("weather", get_weather_details)
workflow.add_node("rag", generate_rag_answer)

# Set entry point
workflow.set_entry_point("detect_intent")

# Add conditional edges
workflow.add_conditional_edges(
    "detect_intent",
    route_by_intent,
    {
        "rag": "rag",
        "weather": "weather"
    }
)

# Add edges to end
workflow.add_edge("rag", END)
workflow.add_edge("weather", END)

graph = workflow.compile()