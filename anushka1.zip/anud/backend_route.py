from langchain_core.prompts import PromptTemplate
from langchain_core.runnables import RunnableLambda
from langchain_openai import ChatOpenAI

router_prompt = """
You are a router and information extractor. Classify the user input into one of two categories:

1. "weather" — if the user is asking about current weather, temperature, forecast, rain, snow, etc.
2. "rag" — if the user is asking a question that requires searching or retrieving from a document or knowledge base.

If the category is "weather", also extract the city name mentioned in the question.

Respond in the following JSON format:
{{
  "destination": "<weather or rag>",
  "city": "<city name if destination is weather, otherwise null>"
}}

Examples:
- "What's the weather like in Paris today?" →
  {{
    "destination": "weather",
    "city": "Paris"
  }}

- "Is it going to rain tomorrow in Seattle?" →
  {{
    "destination": "weather",
    "city": "Seattle"
  }}

- "Tell me about the mission of the Apollo program." →
  {{
    "destination": "rag",
    "city": null
  }}

User question:
\"\"\"{question}\"\"\"
"""

# Setup the prompt
prompt = PromptTemplate.from_template(router_prompt)

# LLM used for classification
llm = ChatOpenAI(
    model="mistralai/mistral-small-3.2-24b-instruct:free",
    temperature=0.0,
    max_retries=2,
    openai_api_key="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",
    openai_api_base="https://openrouter.ai/api/v1",
)

# Create the classifier
import json

def parse_response(output):
    try:
        output = output.content.replace("```json", "")
        output = output.replace("```", "")
        parsed = json.loads(output.strip())
        destination = parsed.get("destination", "default")
        city = parsed.get("city", None) if destination == "weather" else None
        return {"destination": destination, "city": city}
    except Exception:
        return {"destination": "default", "city": None}

classifier = prompt | llm |parse_response

